﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Visa_Form_Project
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String LoginAs;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int count;
            SqlConnection cn = new SqlConnection("initial catalog = visaDB;integrated security =true;server=VDILEWVPNTH512");
            cn.Open();
            SqlCommand cmd;
            if (LoginAs == "Admin")
            {
                cmd = new SqlCommand("select count(*) from admin where AId='" + TextBox1.Text + "' and Apwd = '" + TextBox2.Text + "'");
                Response.Redirect("AdminMain.aspx");
                count = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(count);
                if (count == 1)
                {
                    Response.Redirect("AdminMain.aspx");
                }
                else
                {
                    Response.Write("Invalid Username or Password");
                }
            }
            else if (LoginAs == "HR")
            {
                cmd = new SqlCommand("select count(*) from HR where HRId='" + TextBox1.Text + "' and HRpwd = '" + TextBox2.Text + "'");
                Response.Redirect("HRMain.aspx");
                count = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(count);
                if (count == 1)
                {
                    Response.Redirect("HRMain.aspx");
                }
                else
                {
                    Response.Write("Invalid Username or Password");

                }
            }
            else if (LoginAs == "Emp")
            {

                cmd = new SqlCommand("select count(*) from Emp where EmpId='" + TextBox1.Text + "' and Emppwd = '" + TextBox2.Text + "'");
                Response.Redirect("EmpMain.aspx");
                count = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(count);
                if (count == 1)
                {
                    Response.Redirect("EmployeeMain.aspx");
                }
                else
                {
                    Response.Write("Invalid Username or Password");
                }
            }
        }
            protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
            {
                LoginAs = "Admin";
            } 

        protected void RBEmployee_CheckedChanged(object sender, EventArgs e)
        {
            LoginAs = "Emp";
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            LoginAs = "HR";
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Signup.aspx");
        }
    }
}