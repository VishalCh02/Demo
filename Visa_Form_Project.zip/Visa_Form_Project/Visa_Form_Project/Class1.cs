﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace Visa_Form_Project
{
    public class MyComponent
    {
        public DataSet getdata(String s)
        {
            SqlConnection con = new SqlConnection("initial catalog=VisaDB;integrated security=true;server=VDILEWVPNTH512");
            SqlDataAdapter da = new SqlDataAdapter(s, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return (ds);
        }
    }
}